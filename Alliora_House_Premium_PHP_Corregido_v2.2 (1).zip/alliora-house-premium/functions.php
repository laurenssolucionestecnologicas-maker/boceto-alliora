<?php
/** Alliora House Premium — faithful original pages with WordPress routing. */
if (!defined('ABSPATH')) exit;
add_action('after_setup_theme', function () {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('elementor');
});
function alliora_slug_map() {
    return array('index'=>'Home','house'=>'The House','mind'=>'The Mind','body'=>'The Body','table'=>'The Table','membership'=>'Membership','visit'=>'Visit','portal'=>'Portal','journal'=>'The Journal','library'=>'The Library','salon'=>'The Salon','concierge'=>'Concierge','belonging'=>'Belonging','system'=>'The Alliora System');
}
function alliora_import_pages() {
    if (!current_user_can('manage_options')) wp_die('Not allowed');
    check_admin_referer('alliora_import');
    $created=0; $reused=0;
    foreach (alliora_slug_map() as $slug=>$title) {
        $route = $slug === 'index' ? 'home' : $slug;
        $page = get_page_by_path($route, OBJECT, 'page');
        if (!$page) {
            $id=wp_insert_post(array('post_title'=>$title,'post_name'=>$route,'post_type'=>'page','post_status'=>'publish','post_content'=>''),true);
            if (!is_wp_error($id)) { update_post_meta($id,'_alliora_original_slug',$slug); $created++; }
        } else { update_post_meta($page->ID,'_alliora_original_slug',$slug); $reused++; }
    }
    $home=get_page_by_path('home', OBJECT, 'page');
    if ($home) { update_option('show_on_front','page'); update_option('page_on_front',$home->ID); }
    flush_rewrite_rules(false);
    wp_safe_redirect(add_query_arg(array('page'=>'alliora-setup','done'=>1,'created'=>$created,'reused'=>$reused),admin_url('themes.php')));
    exit;
}
add_action('admin_post_alliora_import','alliora_import_pages');
add_action('admin_menu', function(){add_theme_page('Alliora Setup','Alliora Setup','manage_options','alliora-setup','alliora_setup_screen');});
function alliora_setup_screen() {
    echo '<div class="wrap"><h1>Alliora House — 14 Pages</h1>';
    if (isset($_GET['done'])) echo '<div class="notice notice-success"><p>Pages connected. Created: '.absint($_GET['created']??0).'; reused: '.absint($_GET['reused']??0).'. Existing content was not deleted.</p></div>';
    echo '<p>Connects the 14 original page designs to WordPress routes. Existing pages and their content are preserved.</p>';
    echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="alliora_import">';
    wp_nonce_field('alliora_import');submit_button('Create / connect 14 pages');echo '</form>';
    echo '<p><strong>Editing:</strong> Original designs are rendered from the PHP theme and original HTML. Elementor can edit an alternate page layout, but cannot automatically turn these HTML designs into Elementor widgets.</p>';
    echo '<p><strong>Check pages:</strong> ';
    foreach(alliora_slug_map() as $slug=>$title){$route=$slug==='index'?'home':$slug;$url=$slug==='index'?home_url('/'):home_url('/'.$route.'/');echo '<a target="_blank" rel="noopener" style="margin-right:12px" href="'.esc_url($url).'">'.esc_html($title).'</a>';}
    echo '</p></div>';
}
function alliora_has_elementor_layout() {
    $id=get_queried_object_id();
    return $id && get_post_meta($id,'_elementor_edit_mode',true)==='builder' && !empty(get_post_meta($id,'_elementor_data',true));
}
function alliora_is_elementor_editing() {
    return isset($_GET['elementor-preview']) || (isset($_GET['action']) && $_GET['action']==='elementor');
}
function alliora_elementor_content() {
    get_header();
    echo '<main id="content" class="alliora-editor-content">';
    if(have_posts()) while(have_posts()) {the_post();echo '<article id="post-'.esc_attr(get_the_ID()).'">';the_content();echo '</article>';}
    echo '</main>';
    get_footer();
}
function alliora_render_original() {
    // Elementor editor and saved Elementor layouts need the WordPress content loop.
    if (alliora_is_elementor_editing() || alliora_has_elementor_layout()) {alliora_elementor_content();return;}
    $slug = is_front_page() ? 'index' : get_post_meta(get_queried_object_id(),'_alliora_original_slug',true);
    if (!$slug) {$slug=get_post_field('post_name',get_queried_object_id());if ($slug==='home') $slug='index';}
    $slug=sanitize_key($slug);
    if (!array_key_exists($slug,alliora_slug_map())) {alliora_elementor_content();return;}
    $file=get_template_directory().'/original/'.$slug.'.html';
    if (!is_readable($file)) {alliora_elementor_content();return;}
    $html=file_get_contents($file);
    // All original links use these placeholders. Preserve original HTML/CSS/JS verbatim.
    $base=trailingslashit(home_url('/'));
    $html=str_replace(array('{{ALLIORA_HOME}}','{{ALLIORA_BASE}}'),array($base,$base),$html);
    // Insert WordPress hooks without wrapping the original full HTML document.
    ob_start();wp_head();$head=ob_get_clean();
    if (stripos($html,'</head>')!==false) $html=preg_replace('/<\/head>/i','<!--ALLIORA_WP_HEAD-->',$html,1);
    // PHP preg_replace cannot accept a callback. Use a literal-safe replacement instead.
    $html=str_replace('<!--ALLIORA_WP_HEAD-->',$head.'</head>',$html);
    ob_start();wp_footer();$footer=ob_get_clean();
    $html=preg_replace('/<\/body>/i','<!--ALLIORA_WP_FOOTER-->',$html,1);
    $html=str_replace('<!--ALLIORA_WP_FOOTER-->',$footer.'</body>',$html);
    echo $html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- trusted bundled HTML.
}


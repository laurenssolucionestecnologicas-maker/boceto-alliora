<?php if (!defined('ABSPATH')) exit; alliora_render_original();

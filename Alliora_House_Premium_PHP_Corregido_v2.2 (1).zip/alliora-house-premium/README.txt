Alliora House Premium v2.1.0
Distinct theme folder: alliora-house-premium.
All 14 original HTML pages are included.
Elementor editing: uses WordPress the_content() in editor and on public pages when Elementor content has been saved.
WARNING: Saving a blank Elementor layout does not turn original HTML into Elementor widgets. Existing original HTML is retained as the default for pages without Elementor layout.
Use Appearance > Alliora Setup to create/connect missing pages. Back up before changing themes.
